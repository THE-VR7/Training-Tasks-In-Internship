using System;

namespace Parking.Model
{

  public class Vehicle
  {

    // constructor for the Vehicle Class
    public Vehicle(string id, VehicleType typeOfSlot)
    {
    this.VehicleNumber = id;
    this.TypeOfSlot = typeOfSlot;
    }  

    public string VehicleNumber { get; set;}

    public VehicleType TypeOfSlot { get; set;}

  }

}