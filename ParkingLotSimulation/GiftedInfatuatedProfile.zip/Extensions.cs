using System;
using System.ComponentModel;
using System.Reflection;
using System.Linq;

namespace ExtensionMethods
{
  public static class MyExtensions
  {
    public static string GetDescription(Enum e)
    {
        var attribute =
            e.GetType()
                .GetTypeInfo()
                .GetMember(e.ToString())
                .FirstOrDefault(member => member.MemberType == MemberTypes.Field)
                .GetCustomAttributes(typeof(DescriptionAttribute), false)
                .SingleOrDefault()
                as DescriptionAttribute;

        return attribute?.Description ?? e.ToString();
    }
  }
}