using System;
using System.Linq;
using System.Collections.Generic;
using Parking.Model;
using ParkingLot.Exceptions;

namespace Parking.Application
{
  public class ParkingApplication 
  {
    // Array for Ticket
    public List<Ticket> ArrOfTicket; 
    
    // Slot array 
    public Slot[] ArrOfSlot;

    // Keep the Count of the Tickets which have been issued till now.
    public int TicketCount;

    // Initiialize the Parkign Lot with the values provided by User
    void IntitializeParkingLot(int twoWheelerSlot, int fourWheelerSlot, int heavyVehicleSlot)
    {
      int totalSpot = twoWheelerSlot + fourWheelerSlot + heavyVehicleSlot;

      ArrOfTicket = new List<Ticket>();
      
      ArrOfSlot = new Slot[totalSpot];
      
      this.TicketCount = 0;

      this.IntitializeSLots(twoWheelerSlot,fourWheelerSlot,heavyVehicleSlot);
    }


    // Initialize the Parking Slot 
    void IntitializeSLots(int twoWheelerSlot, int fourWheelerSlot, int heavyVehicleSlot)
    {
      int currentSlot = 0;
      
      for(int index = 0; index < twoWheelerSlot ; index++)
      {
        ArrOfSlot[currentSlot] = new Slot(currentSlot+1, VehicleType.TwoWheeler);
        currentSlot++;
      }

      for(int index = 0; index < fourWheelerSlot ; index++)
      {
        ArrOfSlot[currentSlot] = new Slot(currentSlot+1, VehicleType.FourWheeler);
        currentSlot++;
      }

      for(int index = 0; index < heavyVehicleSlot ; index++)
      {
        ArrOfSlot[currentSlot] = new Slot(currentSlot+1, VehicleType.HeavyVehicle);
        currentSlot++;
      }
    }

    // Display the details of all the slots 
    void DisplaySlotsOccupancy()
    {
      try
      {
        for(int index = 0; index < ArrOfSlot.Length ; index++ )
        {
          ArrOfSlot[index].SlotOccupancyDetail();
        }
      }
      catch(Exception)
      {
        Console.WriteLine("\nNo Slots to Display");
      }
    }


    // Check if any parking slot of given vehicleType exists
    Slot CheckSlotAvailability(VehicleType vehicleType)
    {
      try
      {
        return ArrOfSlot.FirstOrDefault(slot => slot.TypeOfSlot == vehicleType && slot.IsAvailable);
      }
      catch(Exception)
      {
      }
      return null;
    }

  
    // Get the Vehicle details from user and return vehicle Object
    Vehicle GetVehicleDetails()
    {
      Console.Write("Enter the Vehicle Number : "); 
      string vehicleNumber = Console.ReadLine();

      Console.WriteLine("\n1.) Two Wheeler\n2.) Four Wheeler\n3.) Heavy Vehicle");
      Console.Write("Choose the Vehicle Type : "); 
    
      VehicleType vehicleType;
      
      while(true)
      {
        int choiceOfVehicle = Convert.ToInt32(Console.ReadLine());
        
        if(Enum.IsDefined(typeof(VehicleType),choiceOfVehicle))
        {
          vehicleType = (VehicleType)choiceOfVehicle;
          break;
        }
        else
        {
          Console.WriteLine("Wrong Choice -- Please Enter Again");
        }
      }
      return new Vehicle(vehicleNumber,vehicleType);
    }

  
    // Park the Vehicle and Book the Ticket
    void ParkVehicle()
    {

      Vehicle currentVehicle = GetVehicleDetails();

      Console.WriteLine("Got the vehicle details");

      Slot availableSlot = CheckSlotAvailability(currentVehicle.TypeOfSlot);
      
      if(availableSlot == null)
      {
        Console.WriteLine("\nSorry ! There is No Slot Available");
        return;
      }
      else
      {
        Ticket newTicket = new Ticket(TicketCount++);
        
        newTicket.IssueTicket(currentVehicle,availableSlot.Id);
        
        ArrOfTicket.Add(newTicket);
        
        availableSlot.ChangeAvailability();
        
        Console.WriteLine("\nTicket Issued. Ticket Details are : \nTicket ID - {0}",newTicket.Id);
        Console.WriteLine("Ticket Issue Date and Time : {0}",(newTicket.InTime).ToString("ddd MMM %d, yyyy  hh:mm:ss tt"));
      }
    }


    // Check IF ticket exists in our array of tickets and return it 
    Ticket GetUserTicket(int ticketId)
    {
      try
      {
        return ArrOfTicket.FirstOrDefault(ticket => ticket.Id == ticketId);
      }
      catch(Exception)
      {
        throw new CustomException("No Tickets Found");
      }
    }


    // Get the Slot details
    Slot GetSlot(int slotId)
    {
      return ArrOfSlot.FirstOrDefault(slot => slot.Id == slotId);
    }

    // Display the details when user will be un Parking the vehicle
    void DisplayTicketDetails(Ticket ticket)
    { 
      Console.WriteLine($"Cost of Parking is Rs {ticket.TotalCost} for {ticket.TimeDiffrence} Hours");
    }


    // Park the Vehicle and Book the Ticket
    void UnParkVehicle()
    {
      Console.Write("\nEnter the TickedId : ");
      int ticketNumber = Convert.ToInt32(Console.ReadLine());

        try
        {

          Ticket currentTicket = GetUserTicket(ticketNumber);
          
          if(currentTicket == null)
          {
            throw new CustomException("Sorry !! No such Ticket exists in our Database");
          }
          else if(!currentTicket.IsValid)
          {
            throw new CustomException("Sorry !! Your Ticket is Not Valid AnyMore");  
          }

          Slot currentSlot = GetSlot(currentTicket.SlotId);
          
          if(currentSlot == null)
          {
            throw new CustomException("No Such Slot Exists");
          }
          else if(currentSlot.IsAvailable)
          {
            throw new CustomException("There is No Vehicle at the Slot.");
          }
          
          Vehicle currentVehicle = currentTicket.LinkedVehicle;

          if(currentVehicle == null)
          {
            throw new CustomException("No Such Vehicle Exists");
          }
          
          currentTicket.OutTime = DateTime.Now;

          currentSlot.ChangeAvailability();
          
          this.DisplayTicketDetails(currentTicket);

        }
        catch(CustomException exception)
        {
          Console.WriteLine("\n"+exception.Message);
          return;
        }
    }


    // Display the menu 
    int DisplayMenu()
    {
      Console.WriteLine("\n1.) Initialize the parking lot");
      Console.WriteLine("2.) See Parking Lot current occupancy details.");
      Console.WriteLine("3.) Park Vehicle and Issue Ticket");
      Console.WriteLine("4.) Un-park Vehicle");
      Console.WriteLine("Press 0 To Exit");
      Console.Write("Enter your Option : ");
      return Convert.ToInt32(Console.ReadLine());
    }

    public static void Main (string[] args) 
    {
      ParkingApplication parkingLot = new ParkingApplication();
      
      // Display the menu and ask user to enter the option
      MenuSection : 
      
        int selectedMenuOption = parkingLot.DisplayMenu();

        switch(selectedMenuOption)
        {
          case 1 : 
                  Console.Write("Enter the Value of M : ");
                  int m = Convert.ToInt32(Console.ReadLine());
                  
                  Console.Write("Enter the Value of N : ");
                  int n = Convert.ToInt32(Console.ReadLine());
                  
                  Console.Write("Enter the Value of O : ");
                  int o = Convert.ToInt32(Console.ReadLine());
                  
                  parkingLot.IntitializeParkingLot(m,n,o);
                  Console.WriteLine("Parking Lot is Initialized");
                  break;
          
          case 2 :
                  Console.WriteLine("\nParking Lot current occupancy details are as follows : \n");
                  parkingLot.DisplaySlotsOccupancy();
                  break;

          case 3 :
                  parkingLot.ParkVehicle();
                  break;

          case 4 :
                  parkingLot.UnParkVehicle();
                  break;

          case 0 :
                  Console.WriteLine("Bye !!!!");
                  return;

          default :
                  Console.WriteLine("Wrong Selection -- Enter Again");
                  break;
        }
        goto MenuSection; 
    }
  }
}