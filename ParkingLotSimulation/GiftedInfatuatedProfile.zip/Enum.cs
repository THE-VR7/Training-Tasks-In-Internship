using System;
using System.ComponentModel;

namespace Parking.Model
{

  public enum VehicleType
  {
    [Description("No Vehicle")]
    None = 0,
    
    [Description("Two Wheeler")]
    TwoWheeler,

    [Description("Four Wheeler")]
    FourWheeler,
    
    [Description("Heavy Vehicle")]
    HeavyVehicle,
  }

  public class GetDescription{
    
  }

}