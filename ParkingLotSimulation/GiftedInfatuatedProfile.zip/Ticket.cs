using System;
using Parking.Model;

namespace Parking.Application
{

  public class Ticket 
  {
    // Constructo to initialize the Ticket woth the Slot Number
    public Ticket(int id)
    {
      this.Id = id;
    }
    
    public int Id { get;}
    
    public Vehicle LinkedVehicle { get; set; }
    
    public int SlotId { get; set;}

    public bool IsValid
    {
      get
      {
        return (this.OutTime == null);
      }
    }
    
    public int CostPerHour 
    { 
      get
      {
        switch((this.LinkedVehicle).TypeOfSlot)
        {
          case VehicleType.TwoWheeler : 
                                  return 125;
            case VehicleType.FourWheeler :
                                  return 250;
            case VehicleType.HeavyVehicle :
                                  return 500;  
            case VehicleType.None : 
                                  return 0;  
        }
        return 0;
      }
    }

    public double TotalCost 
    { 
      get
      {
        return this.TimeDiffrence * (double)this.CostPerHour;
      }
    }

    public DateTime InTime { get; set;}
    
    public DateTime? OutTime { get; set;}

    public double TimeDiffrence
    {
      get
      {
        TimeSpan timeDiffrence = (OutTime != null) ? (OutTime.Value).Subtract(InTime) : TimeSpan.FromHours(0);
        return ((double)timeDiffrence.Hours == 0) ? 0.50 : (double)timeDiffrence.Hours;
      }
    }

    // Issue the ticket and give the details of vehicle and slot
    public void IssueTicket(Vehicle vehicle, int slotId)
    {
      this.LinkedVehicle = vehicle;
      this.SlotId = slotId;
      this.InTime = DateTime.Now;
    }
  }
}