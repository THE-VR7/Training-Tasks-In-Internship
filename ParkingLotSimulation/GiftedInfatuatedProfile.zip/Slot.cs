using System;
using Parking.Model;
using ExtensionMethods;

namespace Parking.Application
{

  public class Slot
  {
    // constructor for the Vehicle Class
    public Slot(int id, VehicleType typeOfSlot)
    {
    this.Id = id;
    this.IsAvailable = true;
    this.TypeOfSlot = typeOfSlot;
    }  

    public int Id { get; set;}

    public VehicleType TypeOfSlot { get; set;}

    public bool IsAvailable { get; set; }

    public string SlotType
    {
      get
      {
        return MyExtensions.GetDescription(this.TypeOfSlot);
      }
    }


    // Get the current status of the slot
    public string SlotStatus
    {
      get
      {
        return this.IsAvailable ? "Available" : "Not Available";
      }
    }


    // Change the availability when the vehicle is removed
    public void ChangeAvailability()
    {
      this.IsAvailable = !this.IsAvailable;
    }


    // Display the Slot Occupany Details
    public void SlotOccupancyDetail()
    {
      Console.WriteLine($"Slot_{this.Id} of Type {this.SlotType}  is {this.SlotStatus}");
    }

    
  }
}