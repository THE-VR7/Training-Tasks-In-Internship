using System;
using System.Linq;
using System.Collections.Generic; 
using SwitchBoard.Model;

namespace SwitchBoard.Application
{

  class SwitchBoard 
  {

    // Constructor to initialize the Switches
    public SwitchBoard(int switches)
    {
      this.MaxSwitches = switches;
    }

    int MaxSwitches;

    // Initializing the Devices and Link them with Switches
    void InitializeDevices(List<Electronic> devices, List<Switch> switches,int numberOfFan,int numberOfAc,int numberOfBulb)
    {
            
      // Initializing the Items with their default Values
      int deviceItem = 1;
      
      var remainingSwitches = switches.SkipWhile(curswitch => curswitch.DeviceId != -1);
      
      int maxSwitchCount = remainingSwitches.Count();

      int currentSwitchIndex = 0;

      // Add the Fans and link them with the switches
      for(int index=0; index < numberOfFan && currentSwitchIndex < maxSwitchCount ; index++)
      {
        remainingSwitches.ElementAt(currentSwitchIndex++).LinkDevice(deviceItem);
        devices.Add(new Fan(DeviceType.Fan, deviceItem++, index+1));
      }


      // Add the ACs and link them with the switch
      for(int index=0; index < numberOfAc && currentSwitchIndex < maxSwitchCount ; index++)
      {
        remainingSwitches.ElementAt(currentSwitchIndex++).LinkDevice(deviceItem);
        devices.Add(new Ac(DeviceType.Ac, deviceItem++, index+1));
      }


      // Add the Bulbs and link them with the switch
      for(int index=0; index < numberOfBulb && currentSwitchIndex < maxSwitchCount ; index++)
      {
        remainingSwitches.ElementAt(currentSwitchIndex++).LinkDevice(deviceItem);
        devices.Add(new Bulb(DeviceType.Bulb, deviceItem++, index+1));
      }

    }

    // Initalizing the Devices and Switches
    void InitializeSwitches(List<Switch> switches)
    {
      for(int index=0; index<this.MaxSwitches; index++)
      {
        switches.Add(new Switch(index+1));
      }
    }

    // Show every Item with their Name and Status
    public void ShowElectronicMenu(List<Electronic> devices)
    {
      Console.WriteLine("\nElectronic Items List: ");
      for(int index=0;index<devices.Count ;index++)
      {
        devices.ElementAt(index).Display();
      }
      // Console.WriteLine( ((Fan)devices[0]).NumberOfWings );
    }

    public void ChangeStatusOfElectronicItem(List<Electronic> devices,List<Switch> switches)
    {
      while(true)
      {
        Console.Write("Enter the Device Number or Press 0 to Exit : ");
        int selectedDeviceId =  Convert.ToInt32(Console.ReadLine());
        
        if(selectedDeviceId == 0)
        {
          break;
        }

        SelectAgain :
          try
          {
            
            Switch selectedSwitch = switches.Single(currentSwitch => currentSwitch.DeviceId == selectedDeviceId);

            Electronic selectedDevice = devices.Single(device => device.Id == selectedSwitch.DeviceId);
            
            // Options which will be provided when user selects a valid Device
            Console.WriteLine($"\n1.) Switch {selectedDevice.Name}{selectedDevice.ItemId} {selectedSwitch.SwitchStatus(!selectedSwitch.IsSwitchedOn)}");
            
            Console.WriteLine("2.) Back");
            
            int currentSelection = Convert.ToInt32(Console.ReadLine());
            
            if(currentSelection == 1)
            {
              selectedDevice.ChangeRunningStatus();
              selectedSwitch.ChangeStatus();
            }
            else if(currentSelection != 2)
            {
              Console.WriteLine("\nWrong Selection -->  Select Again");
              goto SelectAgain;
            }
            
          }
          catch(Exception )
          {
            Console.WriteLine("\nNo Device with that Device Number, Please Select Again\n");
            continue;
          }

        ShowElectronicMenu(devices);  
      }

      Console.WriteLine("Good Bye!!");
    }

    // Main Function
    public static void Main(string[] args) 
    {
      // Initialize the SwitchBoard
      SwitchBoard switchBoard = new SwitchBoard(50);

      // Take the details of the quantity of fans,Acs & Bulbs
      Console.WriteLine("Enter the Required Details :");
      
      Console.Write("Number of Fans: ");
      int numberOfFan =  Convert.ToInt32(Console.ReadLine());
      
      Console.Write("Number of ACs: ");
      int numberOfAc =  Convert.ToInt32(Console.ReadLine());
      
      Console.Write("Number of Bulbs: ");
      int numberOfBulb =  Convert.ToInt32(Console.ReadLine());
      
      
      // Creating List of superclass to contain elements of every superclass
      List<Electronic> devices = new List<Electronic>();

      List<Switch> switches = new List<Switch>(switchBoard.MaxSwitches);

      // Initialize switches
      switchBoard.InitializeSwitches(switches);

      // Initialize the devices and Link them with Swtiches
      switchBoard.InitializeDevices(devices,switches,numberOfFan,numberOfAc,numberOfBulb);

      // Show the Initial Menu Of Items
      switchBoard.ShowElectronicMenu(devices);

      // This function will execute the whole process of changing the status of Electronic Item
      switchBoard.ChangeStatusOfElectronicItem(devices,switches);
    
    }
  }
}