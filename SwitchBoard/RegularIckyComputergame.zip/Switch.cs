using System;
using SwitchBoard.Model;

namespace SwitchBoard.Application
{

  // Electronic Class which will be inherited by Fans,Acs,Bulbs Class
  class Switch{
    
    // Constructor to initialize the Electronic item's name 
    public Switch(int id)
    {
    this.Id = id;
    this.DeviceId = -1;
    }

    // Link Device with the Switch
    public void LinkDevice(int deviceId)
    {
    this.DeviceId = deviceId;
    }

    public int Id {get; set;}

    public int DeviceId {get; set;}
    
    public bool IsSwitchedOn{ get; set;}


    // Get the Status of Device 
    public string SwitchStatus(bool isSwitchedOn)
    {
      return isSwitchedOn ? "ON" : "OFF";
    }

    // This function will be called to change the status of Device
    public void ChangeStatus()
    {
      this.IsSwitchedOn = !this.IsSwitchedOn;
    }
  }


}