using System;

namespace SwitchBoard.Model{

// Bulb Class
public class Bulb : Electronic{
  // Constructor
  public Bulb(DeviceType Item,int Id,int ItemId) : base(Item , Id)
  {
    this.DeviceId = ItemId;
    this.NumberOfWings = 0;
  }

  public int NumberOfWings { get; set;}

  // @Override
  public override void Display()
  {
    Console.WriteLine($"{this.Id}.) {this.Name}{this.DeviceId} is \"{this.DeviceStatus(this.IsRunning)}\"");
  }


}

}