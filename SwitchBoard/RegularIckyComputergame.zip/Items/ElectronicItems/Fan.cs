using System;

namespace SwitchBoard.Model{

// Fan Class 
public class Fan : Electronic{
  // Constructor
  public Fan(DeviceType Item,int Id,int ItemId) : base(Item , Id)
  {
    this.DeviceId = ItemId;
    this.NumberOfWings = 3;
  }
  
  public int NumberOfWings { get; set;}

  // @Override
  public override void Display()
    {
      Console.WriteLine($"{this.Id}.) {this.Name}{this.DeviceId} is \"{this.DeviceStatus(this.IsRunning)}\"");
    }

}

}