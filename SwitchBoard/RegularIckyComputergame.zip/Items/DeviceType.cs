using System;
namespace SwitchBoard.Model
{

  // Enum to tell which Type of Device is selected
  public enum DeviceType
  {
      None,
      Fan,
      Ac,
      Bulb
  }

}