using System;
namespace SwitchBoard.Model
{

  // Electronic Class which will be inherited by Fans,Acs,Bulbs Class
  public class Electronic
  {
    
    // Constructor to initialize the Electronic item's name 
    public Electronic(DeviceType deviceType , int deviceId)
    {

    this.Id = deviceId;
    
    this.TypeOfDevice = deviceType;
    
    }

    public int Id {get; set;}

    public bool IsRunning{ get; set;}
    
    public DeviceType TypeOfDevice { get; set; }

    public int ItemId {get; set;}

    public string Name
    {
      get
      {
        switch(this.TypeOfDevice)
        {
          case DeviceType.Fan :
                  return "Fan";
          case DeviceType.Ac :
                  return "Ac";
          case DeviceType.Bulb:
                  return "Bulb";
          case DeviceType.None :
                  return "No Device";                        
        }
        return "";
      }
    }

    // Get the Status of Device 
    public string DeviceStatus(bool isRunning)
    {
      return isRunning ? "ON" : "OFF";
    }

    // This will display the name with the status of Electronic Item
    public virtual void Display()
    {
      Console.WriteLine($"{this.Id}.) {this.Name} is \"{this.DeviceStatus(this.IsRunning)}\"");
    }

    // This function will be called to change the status of Device
    public void ChangeRunningStatus()
    {
      this.IsRunning = !this.IsRunning;
    }
  }


}